import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-products-for-admin',
  templateUrl: './products-for-admin.component.html',
  styleUrls: ['./products-for-admin.component.css']
})
export class ProductsForAdminComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
