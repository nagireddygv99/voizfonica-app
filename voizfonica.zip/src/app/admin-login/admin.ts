export class Admin {
    adminUserName:any;
    adminName:any;
    adminPassword:any;
    
}
