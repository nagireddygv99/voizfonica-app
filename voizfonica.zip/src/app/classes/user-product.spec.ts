import { UserProduct } from './user-product';

describe('UserProduct', () => {
  it('should create an instance', () => {
    expect(new UserProduct()).toBeTruthy();
  });
});
