export class Plan {
    planId:any;
    planAmount:any;
    planDescription:any;
    planDuration:any;
    productId:any;

}
