export class UserProduct {
    userPhoneNumber:any;
    productId:any;
    userNumber:any;
}
