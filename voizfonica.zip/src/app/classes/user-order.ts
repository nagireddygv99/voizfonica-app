export class UserOrder {
    orderId:any;
    userPhoneNumber:any;
    planId: any;
    orderStatus:any;
    rechargedNumber:any;
    planActivationDate:any;
    planExpiryDate:any;
}
