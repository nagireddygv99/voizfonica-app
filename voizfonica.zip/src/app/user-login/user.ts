export class User {
    userPhoneNumber:any;
    userEmailId:any;
    userFirstName:any;
    userLastName:any;
    userPassword:any; 
  }
  